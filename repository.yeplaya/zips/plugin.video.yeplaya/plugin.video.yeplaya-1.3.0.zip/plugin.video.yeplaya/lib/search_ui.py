# -*- coding: utf-8 -*-
# Module: search_ui
# Author: onykmin
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

"""Search, display series list, and new search UI functions."""

import xbmc
import xbmcgui
import xbmcplugin

from lib.api import api, parse_xml, is_ok, revalidate
from lib.utils import todict, get_url, popinfo, ask, tolistitem, sizelize, get_handle, get_addon, set_webshare_id, set_video_info, apply_playback_state
from lib.cache import loadsearch, removesearch, storesearch, build_cache_key, cache_set, clear_cache
from lib.state import build_mv_state_key, get_states
from lib.grouping import fetch_and_group_series
from lib.search import calculate_search_relevance
from lib.logging import log_debug
from lib.playback import toqueue
from lib.ui import NONE_WHAT, CATEGORIES, SORTS
from lib.favorites_ui import add_favorite_context_entry

_handle = get_handle()
_addon = get_addon()


def _setting_int(key, default):
    """Read int setting with fallback for empty/garbage values."""
    try:
        raw = _addon.getSetting(key)
        if raw is None or raw == '':
            return default
        return int(raw)
    except (ValueError, TypeError):
        return default


def dosearch(token, what, category, sort, limit, offset, action, params=None,
             update_listing=False):
    response = api('search',{'what':'' if what == NONE_WHAT else what, 'category':category, 'sort':sort, 'limit': limit, 'offset': offset, 'wst':token, 'maybe_removed':'true'})
    if response is None:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        # Close the directory on API failure — returning without endOfDirectory
        # leaves Kodi's container stuck on a spinner / the previous listing.
        xbmcplugin.endOfDirectory(_handle, succeeded=False, updateListing=update_listing)
        return
    xml = parse_xml(response.content)
    if is_ok(xml):

        # Check if flat view requested (either by URL param or user setting)
        force_flat = params and 'flat' in params if params else False

        # Check user's default view preference
        if not force_flat:
            default_view = _addon.getSetting('default_view')
            prefer_series = (default_view == '0')  # '0' = Series view, '1' = Flat
            if not prefer_series:
                force_flat = True

        # Collect all files
        files = []
        for file in xml.iter('file'):
            item = todict(file)
            files.append(item)

        if not files and offset == 0:
            popinfo(_addon.getLocalizedString(30108), icon=xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(_handle, updateListing=update_listing)
            return

        # Check if we should show series view (only on first page and if not forced flat)
        # Also show series view if 'page' param present (paginated series view)
        show_series_view = not force_flat and files and (offset == 0 or (params and 'page' in params))

        if show_series_view:
            # Fetch ALL pages for accurate counts (pass first page to avoid re-fetch)
            try:
                first_total = int(xml.find('total').text)
            except (AttributeError, ValueError, TypeError):
                first_total = None
            grouped = fetch_and_group_series(token, what, category, sort,
                                             first_page_files=files, first_page_total=first_total)

            # Show series/movie view if we found any series OR movies
            if grouped and (len(grouped['series']) >= 1 or len(grouped.get('movies', {})) >= 1):
                # Cache for navigation (thread-safe)
                cache_key = build_cache_key(what, category, sort)
                cache_set(cache_key, grouped)

                # Get page number from params
                page = int(params.get('page', 0)) if params else 0

                # Display series list instead of flat files
                display_series_list(grouped, what, category, sort, limit, page,
                                    update_listing=update_listing)
                return

        # ORIGINAL: Flat file display (backward compatible)
        if offset > 0: #prev page
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30206))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action=action, what=what, category=category, sort=sort, limit=limit, offset=offset - limit if offset > limit else 0, flat=1), listitem, True)

        # This branch only renders when flat view is active, so the queue
        # refresh must carry flat=1 (plus category/sort/limit/offset) to
        # re-enter the SAME flat page. Dropping them made the post-queue
        # refresh fall back to series view and lose the current offset.
        for item in files:
            commands = []
            commands.append(( _addon.getLocalizedString(30214), 'RunPlugin(' + get_url(action='toqueue', toqueue=item['ident']) + ')'))
            listitem = tolistitem(item,commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item['name']), listitem, False)

        try:
            total = int(xml.find('total').text)
        except (AttributeError, ValueError, TypeError):
            total = 0

        if offset + limit < total: #next page
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30207))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action=action, what=what, category=category, sort=sort, limit=limit, offset=offset+limit), listitem, True)

        xbmcplugin.endOfDirectory(_handle, updateListing=update_listing)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(_handle, updateListing=update_listing)


def display_series_list(grouped, what, category, sort, limit, page=0,
                        update_listing=False):
    """Display list of series with counts."""
    log_debug("=== DISPLAY_SERIES_LIST called with page={} ===".format(page))
    xbmcplugin.setContent(_handle, 'tvshows')

    # Merge series, movies, and non_series into unified list sorted by relevance.
    # Treat the NONE_WHAT sentinel (Newest / Biggest browse) as "no query" — it
    # is not a real search term, so relevance-scoring against it would scramble
    # the intended (alphabetical / server-provided) order.
    has_query = bool(what) and what != NONE_WHAT
    all_items = []

    # Add series to unified list
    for k, v in grouped['series'].items():
        score = calculate_search_relevance(v['display_name'], what, k) if has_query else -1
        all_items.append(('series', k, v, score))

    # Add movies to unified list
    if grouped.get('movies'):
        for k, v in grouped['movies'].items():
            score = calculate_search_relevance(v['display_name'], what, k) if has_query else -1
            all_items.append(('movie', k, v, score))

    # Add non_series files to unified list
    if grouped.get('non_series'):
        for file_data in grouped['non_series']:
            score = calculate_search_relevance(file_data['name'], what) if has_query else -1
            all_items.append(('file', file_data['name'], file_data, score))

    # Sort unified list by relevance (or alphabetically if no query)
    if has_query:
        all_items.sort(key=lambda x: (-x[3], x[0] != 'movie', x[1]))
    else:
        all_items.sort(key=lambda x: x[2].get('display_name', x[2].get('name', '')).lower())

    # Pagination config
    items_per_page = 25
    total_items = len(all_items)
    total_pages = max(1, (total_items + items_per_page - 1) // items_per_page)

    original_page = page
    if page < 0:
        page = 0
    elif page >= total_pages:
        page = total_pages - 1
    if page != original_page:
        log_debug("Page {} out of bounds, clamped to {}".format(original_page, page))
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)

    start_idx = page * items_per_page
    end_idx = start_idx + items_per_page

    # Back to search menu button (only on page 2+, since ".." works on page 1)
    if page > 0:
        search_menu_url = get_url(action='search')
        back_url = get_url(action='goto_page', target_url=search_menu_url)
        listitem = xbmcgui.ListItem(label='[{}]'.format(_addon.getLocalizedString(30400)))
        listitem.setArt({'icon': 'DefaultFolderBack.png'})
        listitem.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(_handle, back_url, listitem, False)

    # Option to switch to flat view. Routed through goto_page so the flat
    # listing REPLACES the current series-results frame (updateListing) instead
    # of pushing a sibling ?action=search&...&flat=1 frame. Without this, the
    # series and flat renders of the SAME search both sit on the back-stack, so
    # Back needs two presses to leave the result set ("weird page stacking").
    flat_url = get_url(action='search', what=what, category=category,
                       sort=sort, limit=limit, flat=1)
    listitem = xbmcgui.ListItem(label='[{}]'.format(_addon.getLocalizedString(30401)))
    listitem.setArt({'icon': 'DefaultFile.png'})
    listitem.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(_handle,
        get_url(action='goto_page', target_url=flat_url),
        listitem, False)

    # Display items for current page
    page_items = all_items[start_idx:end_idx]
    # Prime playback state for this page's movie rows in one batched query.
    _movie_keys = [k for t, k, _d, _s in page_items if t == 'movie']
    if _movie_keys:
        get_states([build_mv_state_key(k) for k in _movie_keys])
    for item_type, key, data, score in page_items:
        if item_type == 'series':
            series_name = key
            series_data = data
            season_count = len(series_data['seasons'])
            episode_count = series_data['total_episodes']
            display_name = series_data.get('display_name', series_name.title())

            # Special case: single season with single episode - display as standalone file
            if season_count == 1 and episode_count == 1:
                season_num = list(series_data['seasons'].keys())[0]
                ep_num = list(series_data['seasons'][season_num].keys())[0]
                versions = series_data['seasons'][season_num][ep_num]

                if versions:
                    ep_data = versions[0]
                    label = display_name

                    if len(versions) == 1:
                        commands = []
                        commands.append((
                            _addon.getLocalizedString(30214),
                            'RunPlugin(' + get_url(
                                action='toqueue', toqueue=ep_data['ident']) + ')'
                        ))
                        listitem = tolistitem(ep_data, commands)
                        listitem.setLabel(label)
                        xbmcplugin.addDirectoryItem(_handle,
                            get_url(action='play', ident=ep_data['ident'],
                                   name=ep_data['name'],
                                   series=series_name, season=season_num,
                                   episode=ep_num),
                            listitem, False)
                    else:
                        season_word = _addon.getLocalizedString(30414 if season_count == 1 else 30415)
                        episode_word = _addon.getLocalizedString(30416 if episode_count == 1 else 30417)
                        label = '{0} ({1} {2}, {3} {4})'.format(
                            display_name, season_count, season_word, episode_count, episode_word)
                        listitem = xbmcgui.ListItem(label=label)
                        listitem.setArt({'icon': 'DefaultTVShows.png'})
                        url_params = {'action': 'browse_series'}
                        if series_name:
                            url_params['series'] = series_name
                        if what:
                            url_params['what'] = what
                        if category:
                            url_params['category'] = category
                        if sort:
                            url_params['sort'] = sort
                        url = get_url(**url_params)
                        xbmcplugin.addDirectoryItem(_handle, url, listitem, True)
                continue

            # Normal case: multi-season or multi-episode series
            season_word = _addon.getLocalizedString(30414 if season_count == 1 else 30415)
            episode_word = _addon.getLocalizedString(30416 if episode_count == 1 else 30417)
            label = '{0} ({1} {2}, {3} {4})'.format(
                display_name, season_count, season_word, episode_count, episode_word)

            listitem = xbmcgui.ListItem(label=label)
            listitem.setArt({'icon': 'DefaultTVShows.png'})

            listitem.addContextMenuItems([add_favorite_context_entry({
                'type': 'series',
                'canonical_key': series_name,
                'display_name': display_name,
                'search_query': what,
                'category': category,
                'sort': sort,
            })])

            url_params = {'action': 'browse_series'}
            if series_name:
                url_params['series'] = series_name
            if what:
                url_params['what'] = what
            if category:
                url_params['category'] = category
            if sort:
                url_params['sort'] = sort
            url = get_url(**url_params)
            xbmcplugin.addDirectoryItem(_handle, url, listitem, True)

        elif item_type == 'movie':
            movie_key = key
            movie_data = data
            versions = movie_data['versions']
            year = movie_data['year']
            display_name = movie_data['display_name']

            label = f"{display_name} ({year})"
            if len(versions) > 1:
                version_word = _addon.getLocalizedString(30419)
                label += f" [{len(versions)} {version_word}]"

            listitem = xbmcgui.ListItem(label=label)
            listitem.setArt({'icon': 'DefaultVideo.png'})

            if movie_data.get('plot'):
                set_video_info(listitem, {'plot': movie_data['plot']})

            state_key = build_mv_state_key(movie_key)
            state_cmds = apply_playback_state(listitem, state_key)
            fav_entry = add_favorite_context_entry({
                'type': 'movie',
                'canonical_key': movie_key,
                'display_name': display_name,
                'search_query': what,
                'year': year,
                'category': category,
                'sort': sort,
            })
            listitem.addContextMenuItems((state_cmds or []) + [fav_entry])

            if len(versions) == 1:
                listitem.setProperty('IsPlayable', 'true')
                set_webshare_id(listitem, versions[0]['ident'])
                url = get_url(action='play', ident=versions[0]['ident'],
                             name=versions[0]['name'], movie_key=movie_key)
                xbmcplugin.addDirectoryItem(_handle, url, listitem, False)
            else:
                listitem.setProperty('IsPlayable', 'true')
                set_webshare_id(listitem, versions[0]['ident'])
                url = get_url(
                    action='select_movie_version',
                    movie_key=movie_key,
                    what=what,
                    category=category,
                    sort=sort
                )
                xbmcplugin.addDirectoryItem(_handle, url, listitem, False)

        elif item_type == 'file':
            file_data = data
            commands = []
            commands.append((
                _addon.getLocalizedString(30214),
                'RunPlugin(' + get_url(action='toqueue',
                    toqueue=file_data['ident']) + ')'
            ))

            listitem = tolistitem(file_data, commands)
            xbmcplugin.addDirectoryItem(_handle,
                get_url(action='play', ident=file_data['ident'],
                       name=file_data['name']),
                listitem, False)

    # Next page button
    if end_idx < total_items:
        next_url = get_url(action='search', what=what, category=category,
                    sort=sort, limit=limit, page=page+1)
        log_debug("Creating NEXT page button (direct): {}".format(next_url))
        listitem = xbmcgui.ListItem(label='[{}]'.format(_addon.getLocalizedString(30402)))
        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(_handle, next_url, listitem, True)

    xbmcplugin.endOfDirectory(_handle, updateListing=update_listing)


def search(params):
    log_debug("search() called with params: {}".format(params))
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\ " + _addon.getLocalizedString(30201))
    token = revalidate()

    updateListing=False

    if 'remove' in params:
        removesearch(params['remove'])
        updateListing=True

    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True

    what = None

    if 'what' in params:
        what = params['what']
        log_debug("what from params: {}".format(what))

    if what is not None:
        category = params['category'] if 'category' in params else CATEGORIES[_setting_int('scategory', 0)]
        sort = params['sort'] if 'sort' in params else SORTS[_setting_int('ssort', 0)]
        limit = int(params['limit']) if 'limit' in params else _setting_int('slimit', 25)
        offset = int(params['offset']) if 'offset' in params else 0
        # Store history only on the genuine first entry to a search — NOT on
        # pagination. The series view paginates via 'page' (offset stays 0),
        # the flat view via 'offset'; either present means a later page.
        is_first_page = offset == 0 and 'page' not in params
        if is_first_page and what != NONE_WHAT:
            storesearch(what)
        xbmcplugin.setContent(_handle, 'files')
        # Thread updateListing through: when a context action (toqueue/remove)
        # re-enters this same path to refresh, the re-render must REPLACE the
        # current listing, not push a duplicate frame onto the back-stack.
        dosearch(token, what, category, sort, limit, offset, 'search', params,
                 update_listing=updateListing)
        return
    else:
        history = loadsearch()
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30205))
        listitem.setArt({'icon': 'DefaultAddSource.png'})
        xbmcplugin.addDirectoryItem(_handle, 'plugin://plugin.video.yeplaya/?action=newsearch', listitem, False)

        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30208))
        listitem.setArt({'icon': 'DefaultAddonsRecentlyUpdated.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[1]), listitem, True)

        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30209))
        listitem.setArt({'icon': 'DefaultHardDisk.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[3]), listitem, True)

        for s in history:
            listitem = xbmcgui.ListItem(label=s)
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            commands = []
            commands.append(( _addon.getLocalizedString(30213), 'RunPlugin(' + get_url(action='remove_search',remove=s) + ')'))
            commands.append(add_favorite_context_entry({'type': 'search', 'query': s}))
            listitem.addContextMenuItems(commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=s), listitem, True)
        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing, cacheToDisc=False)


def newsearch(params):
    """Handle new search: keyboard prompt, store term, navigate to results.

    Kodi contract: parent listitem in search() is is_folder=False, so
    Kodi invokes this via PlayMedia, expecting setResolvedUrl. Calling
    endOfDirectory here is the wrong contract; calling setResolvedUrl
    with succeeded=False signals "no playable item, do nothing" so the
    subsequent Container.Update wins without a parent-path race.
    """
    what = ask(None)
    if what is None or what == '':
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
        return
    storesearch(what)
    clear_cache()
    category = CATEGORIES[_setting_int('scategory', 0)]
    sort = SORTS[_setting_int('ssort', 0)]
    limit = _setting_int('slimit', 25)
    url = get_url(action='search', what=what, category=category, sort=sort, limit=limit, offset=0)
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
    xbmc.executebuiltin("Container.Update({})".format(url))
