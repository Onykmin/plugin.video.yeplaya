# -*- coding: utf-8 -*-
# YAWsP Library Package
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html
