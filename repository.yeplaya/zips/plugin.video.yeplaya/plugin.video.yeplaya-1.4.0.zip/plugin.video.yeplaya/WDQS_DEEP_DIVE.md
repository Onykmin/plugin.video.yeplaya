# WDQS Deep Dive — Random Movie Picker

Research + spec only, no implementation; extends RANDOM_MOVIE_RESEARCH.md (round 1).

## 1. Production query + tuning evidence

Pool size vs sitelinks threshold, `COUNT(DISTINCT ?film)`, P31=Q11424:

| threshold | pool | wall | bytes |
|---|---|---|---|
| >=5 | 68,314 | 6.43s | 232 |
| >=10 | 25,043 | 45.45s | 232 |
| >=20 | 8,937 | 25.61s | 231 |
| >=40 | 1,889 | 6.93s | 231 |
| >=80 | 72 | 28.34s | 229 |

```sparql
SELECT (COUNT(DISTINCT ?film) AS ?c) WHERE {
  ?film wdt:P31 wd:Q11424 ; wikibase:sitelinks ?sl . FILTER(?sl >= N)
}
```

Latency is NON-MONOTONIC in pool size — >=5 (largest pool) fastest at 6.43s; >=10 slowest at 45.45s. Threshold can't be tuned for speed; latency dominated by server load/variance, not result-set size. Recommend **>=20** (8,937 films): large enough for variety, popularity-gated. Threshold is a POOL QUALITY choice, not a latency one.

### DISTINCT necessary but insufficient (refines round 1)

- Q7 no DISTINCT, P577 in projection, LIMIT 10 OFFSET 500: 10 rows, only **4 distinct films**, 0.70s. enLabels: Knight Moves x3, What Ever Happened to Baby Jane?, Wildcats, Moon x5.
- Q8 same query+offset WITH DISTINCT: 10 rows, only **1 distinct film** — all 10 "Barbarella". 0.50s.

DISTINCT dedupes the whole selected TUPLE. A film with N values of P577 (publication date) yields N distinct tuples. Multi-valued properties in the projection defeat DISTINCT. cs/en `rdfs:label` are single-valued per language so they don't multiply — P577 is the multiplier.

**Fix, measured:** `GROUP BY ?film` with aggregates.

```sparql
SELECT ?film (MIN(?date) AS ?d) (SAMPLE(?cs) AS ?csL) (SAMPLE(?en) AS ?enL) WHERE {
  ?film wdt:P31 wd:Q11424 ; wikibase:sitelinks ?sl ; wdt:P577 ?date .
  FILTER(?sl >= 20) FILTER(YEAR(?date) >= 1990 && YEAR(?date) <= 2020)
  OPTIONAL { ?film rdfs:label ?cs . FILTER(LANG(?cs)="cs") }
  OPTIONAL { ?film rdfs:label ?en . FILTER(LANG(?en)="en") }
} GROUP BY ?film LIMIT 10 OFFSET 500
```
Q16: HTTP 200, 17.05s, 4,816 bytes, 10 rows, **10 distinct films**. Perfect dedup. Only needed if a year-window variant is used.

| variant | count query | pool | wall |
|---|---|---|---|
| base, `wdt:P31 wd:Q11424`, sitelinks>=20 | — | 8,937 | — |
| + year window `YEAR(?date)` 1990-2020 via P577 | Q14 | 5,354 | 17.71s |
| subclass-inclusive `wdt:P31/wdt:P279* wd:Q11424`, sitelinks>=20 | Q15 | 9,784 | 25.53s |

Q14/Q15 both 231 bytes.

- Year window 1990-2020 costs ~40% of the pool (8,937 → 5,354). Still ample.
- Subclass traversal `P31/P279*` adds 847 films (+9.5%) over direct `P31` — small gain, and it broadens what counts as a "film" (subclasses include things a movie-night picker may not want). Direct `P31 wd:Q11424` recommended.
- Independent in-the-wild confirmation of the P577 fan-out from §1: Q13 (year window, `DISTINCT`, P577 in projection, LIMIT 50 OFFSET 500), HTTP 200, 1.54s, 25,047 bytes, returned 50 rows but only **17 distinct films**, 42 rows with cs — e.g. "Ghost Rider 2"/"Ghost Rider: Spirit of Vengeance" appeared 3x with dates 2012-02-17, 2012-02-23, 2012-03-01; "Smrtonosná past 4.0"/"Live Free or Die Hard" 2x. Reinforces: any year-window variant MUST use the `GROUP BY ?film` form.

### Label retrieval — cs+en, two approaches

- Explicit OPTIONAL + `FILTER(LANG(...))`, Q6, LIMIT 50 OFFSET 1000: 8.85s, 23,484 bytes, 50 rows, 37 with cs.
- Combining explicit OPTIONALs AND `SERVICE wikibase:label` in the same query (Q5, LIMIT 1 OFFSET 4321): FAILED first attempt, HTTP 504 "upstream request timeout" at 65.2s; succeeded on retry, HTTP 200 at 26.29s, 655 bytes.

Recommend explicit `OPTIONAL` + `FILTER(LANG())` ONLY. Do not also add the label `SERVICE` — expensive/fragile in combination.

### OFFSET depth cost (offset is not free)

| offset | limit | wall | rows |
|---|---|---|---|
| 500 | 10 | 0.50-0.70s | 10 |
| 1000 | 50 | 8.85s | 50 |
| 1234 | 1 | 5.34s | 1 |
| 3777 | 1 | 4 repeat runs, see §2.1 | 1 |
| 8500 | 1 | 19.73s | 1 |
| 20000 (overshoot, beyond pool) | 5 | 28.50s | 0 rows, 98 bytes |

Deep OFFSET costs real time (SPARQL scans and discards). Overshoot is the worst case: 28.50s to return nothing. Offset bound must be reasonably accurate.

### Offset-bound strategy — tradeoff + recommendation

A count query is affordable but slow and variable (6.43s-45.45s above) — must NOT run per pick. **Recommend:** cache the count (changes slowly — ~8,937 for >=20) and refresh rarely, alongside pool refresh. Hardcoding a conservative bound risks either never reaching the pool tail (bound too low) or paying the 28.50s/0-row overshoot (bound too high). Overshoot is recoverable (0 rows, not an error) but expensive; a cached count avoids it entirely.

### Recommended production query

```sparql
SELECT DISTINCT ?film ?cs ?en WHERE {
  ?film wdt:P31 wd:Q11424 ;
        wikibase:sitelinks ?sl .
  FILTER(?sl >= 20)
  OPTIONAL { ?film rdfs:label ?cs . FILTER(LANG(?cs) = "cs") }
  OPTIONAL { ?film rdfs:label ?en . FILTER(LANG(?en) = "en") }
}
LIMIT <batch> OFFSET <random 0..8937-batch>
```
Deliberately omits P577 (avoids tuple fan-out that defeats DISTINCT) and omits `SERVICE wikibase:label` (avoids Q5 cost). Year-window variant needs the GROUP BY form (Q16) instead — optional, not required.

## 2. Latency shapes — prefetch vs live vs hybrid

Prefetch feasibility, measured: Q11 = recommended query, LIMIT 2000 OFFSET 0 → HTTP 200, 2.68s, 617,843 bytes raw JSON, 2,000 rows, 1,316 with cs (65.8%). Reduced to minimal `[[cs,en],...]` compact JSON (`separators=(',',':')`, UTF-8, non-ASCII preserved): **70,134 bytes ≈ 68 KiB for 2,000 films**. (`ensure_ascii=True` would inflate to ~78 KB — each Czech diacritic becomes a 6-byte `\uXXXX` escape; `cache.py` writes UTF-8, so 70,134 is the realistic on-disk figure.) One 2.68s query → 2,000-title pool at ~68 KiB — trivially within reach of existing on-disk primitives.

### 2.1 Repeat-run probe — result order is NOT stable

Same query run 4x, ~20s apart, pacing deliberate to stay inside published allowance:

```sparql
SELECT DISTINCT ?film ?cs ?en WHERE { ?film wdt:P31 wd:Q11424 ; wikibase:sitelinks ?sl . FILTER(?sl >= 20) OPTIONAL { ?film rdfs:label ?cs . FILTER(LANG(?cs)="cs") } OPTIONAL { ?film rdfs:label ?en . FILTER(LANG(?en)="en") } } LIMIT 1 OFFSET 3777
```

| run | film | cs | en | wall |
|---|---|---|---|---|
| V1 | Q1200483 | — | Demon Seed | 6.81s |
| V2 | Q808101 | Čas pomsty | Joshua Tree | 23.66s |
| V3 | Q733677 | Match Point | Match Point | 30.96s |
| V4 | Q1086921 | — | Oedipus Rex | 12.73s |

min 6.81s / max 30.96s / mean 18.5s — a 4.5x spread on the IDENTICAL query, same offset, within ~1 minute. Latency variance is inherent, not query-dependent.

A live-per-click design cannot promise a predictable wait: the same pick cost 6.8s once and 31.0s a minute later.

All four HTTP 200, 1 row each (325-436 bytes).

- SAME offset returned FOUR DIFFERENT films. WDQS result order for a query without `ORDER BY` is NOT stable across calls (measured, not assumed).
- Upside: a fixed offset still yields varying films — randomness does not rest on offset choice alone.
- Caveat for hybrid/top-up shape: successive-OFFSET pagination is NOT guaranteed disjoint pages. Top-up pages may both duplicate already-held titles and miss others. A prefetched pool should dedupe on `?film` URI when merging a top-up batch, and cannot treat OFFSET windows as a stable partition of the pool.
- 2 of 4 runs had no cs label, consistent with the coverage range in §4.

### What `lib/cache.py` ACTUALLY is

- In-memory only, dies every menu action: `_series_cache` / `_cache_timestamps` / `_cache_ttls` dicts + `_cache_lock` (lib/cache.py:48-51), `DEFAULT_CACHE_TTL = 300` (:55), `MAX_CACHE_ENTRIES = 50` (:56), `cache_set` (:64), `cache_get` (:86). Verified: no disk I/O inside `cache_set`/`cache_get` bodies. In-memory API CANNOT hold a pool across actions (project gotcha: one menu action = one process).
- Generic ON-DISK primitives exist, take an arbitrary path: `profile_dir()` (:170), `atomic_write_text(path, text)` (:275, unique tmp via `tempfile.mkstemp` + fsync + `os.replace`, opened `encoding='utf8'` at :288), `locked_read_text(path)` (:260, shared fcntl/msvcrt lock), `file_lock(lock_path)` (:230, exclusive lock on sidecar file, safe across the `os.replace` inode swap).
- NO generic on-disk key/value cache API exists. On-disk consumers today: search history — `loadsearch()` (:303) / `savesearch()` (:329) / `storesearch()` (:334), JSON list of strings at `{profile}/search_history`, capped by `shistory` setting (default 20); and the stronger precedent, `lib/favorites.py` — `FAVORITES = 'favorites'` (:24), `MAX_FAVORITES = 200` (:26), `_favorites_path()` (:41) = `os.path.join(profile_dir(), FAVORITES)`, `save_favorites()` (:164-168) writes a versioned envelope `{'version': ENVELOPE_VERSION, 'items': items}` via `atomic_write_text`, read back through `locked_read_text` (:148/:182), mutated under `file_lock(_favorites_path() + '.lock')` (:180), in-memory cache layered on top (`_cached_items`, invalidated by save).

**Verdict:** prefetch pool IS feasible — a versioned-envelope JSON file in `profile_dir()`, mirroring `lib/favorites.py`, holding ~68 KiB for 2,000 titles. NOT available via the existing cache API — this is new code reusing existing, proven primitives. Kill-criterion NOT tripped.

### Three shapes — cost

| shape | cost |
|---|---|
| Live per click | 5.34s (offset 1234), 19.73s (offset 8500), 26.29s (Q5 retry), plus one outright 504 at 65.2s. 5-27s spinner per pick, every pick exposed to WDQS failure/variance. Simplest; always fresh. |
| Prefetch pool + cache | One 2.68s query for 2,000 titles (~68 KiB); clicks instant thereafter; refresh on TTL. New persistence code (favorites-shaped); staleness bounded by TTL; one slow/failing query at refresh time only. |
| Hybrid | Prefetched pool, live top-up when exhausted/expired. |

**Recommend: prefetch pool + cache (hybrid on exhaustion).** A 2,000-title pool makes ~2,000 picks from ONE request — far inside the throttle allowance (§3) — and moves all latency + failure off the click path. The reroll UX precedent already assumes a fast in-process loop — `lib/series_ui.py:424-435` `_pick_random(all_keys, excluded)` + `random.choice(remaining)`, never auto-resetting `excluded` — which a prefetched pool satisfies and a 5-27s live query per reroll does not.

## 3. Failure-mode spec

Published limits, https://www.mediawiki.org/wiki/Wikidata_Query_Service/User_Manual:
- hard query deadline 60 seconds
- "One client (user agent + IP) is allowed 60 seconds of processing time each 60 seconds"
- "One client is allowed 30 error queries per minute"
- "Clients exceeding the limits above are throttled with HTTP code 429. Use Retry-After header to see when the request can be repeated."
- "currently access to the service is limited to 5 parallel queries per IP"

From https://wikitech.wikimedia.org/wiki/Wikidata_Query_Service/Runbook: "Throttling is applied based on overall computing time and error rate to protect from overly eager clients. The throttling is bucketed by user-agent and IP address." An abusive client ignoring 429 "will be banned for a longer duration where all its requests will be denied with an HTTP 403."

Round 1 left WDQS throttling UNVERIFIED — now RESOLVED from published docs. Arithmetic: a 25s query consumes ~42% of the client's entire 60s-per-60s allowance. Two such queries in a minute nearly exhaust it. Live-query-per-reroll self-throttles on a fast-clicking user; a prefetched pool cannot.

### User-Agent policy

Cite https://foundation.wikimedia.org/wiki/Policy:User-Agent_policy:
- "Wikimedia sites require a HTTP User-Agent header for all requests"
- template form: `CoolBot/0.0 (https://example.org/coolbot/; coolbot@example.org) generic-library/0.0`
- contact info may be "an email address, a website, or a wiki user"
- "Scripts should use an informative User-Agent string with contact information, or they may be blocked without notice."

**Addon-specific requirement:** must NOT reuse the shared Webshare session for WDQS. `lib/api.py:23-24` defines `UA` as a spoofed Chrome browser string plus `Referer: https://webshare.cz`, `lib/api.py:31` assigns `_session.headers = HEADERS.copy()`. Sending that generic browser UA to WDQS violates policy above, and since throttling is bucketed by user-agent, is exactly what risks being "blocked without notice". WDQS calls need their own request with an addon-identifying UA (name/version + contact URL). Precedent for module-local headers: `csfd_scraper.py:121/175/358` pass `headers = {'User-Agent': USER_AGENT}` per call.

### Observed reliability under normal courteous load (no load test run — stated explicitly)

- Q5 (LIMIT 1 OFFSET 4321): attempt 1 HTTP 504 "upstream request timeout" at 65.2s; identical query on retry HTTP 200 at 26.29s.
- Plain `requests` probe (GET, params query+format=json, timeout=30, requests 2.32.3): HTTP 502 at 5.54s, 157-byte non-JSON body; identical request ~20s later HTTP 200 at 5.34s.
- Latency range across the whole session: 0.50s to 45.45s. The 45.45s count query sits within 15s of the 60s hard kill. Variance is not explained by query shape: the IDENTICAL single-pick query ranged 6.81s-30.96s across 4 runs in ~1 minute (§2.1).
- Two hard failures (504, 502) across roughly 30 courteous queries.

Corroborating, https://www.wikidata.org/wiki/Wikidata:SPARQL_query_service/query_limits: "Please note the times seen below were collected in 2017, when the SPARQL service was under a much smaller load. The service is now (2026-05) much less responsive." Documented regressions: "0.6s → 9s, 9s → timeout, 7s → 27s".

### Required client behavior

- Check `status_code` BEFORE parsing: WDQS error bodies are not JSON — `r.json()` raised `JSONDecodeError` on the 502. Measured.
- No `Retry-After` header on the observed 502; it's documented for 429. Honor `Retry-After` when present (429), else fixed backoff.
- Never retry more than once or twice, with backoff; never hammer. 429/403 must stop the loop, not retry harder.
- Client timeout at/below the 60s server deadline; a >60s wait is a server timeout, not a slow success.
- Surface failure as a notification and abort cleanly rather than hanging (existing convention `popinfo()`).
- 5xx/timeout at pool-refresh time in the prefetch design is invisible to the user if a stale pool is retained — argument for keeping the last good pool on refresh failure.
- `format=json` query param and `Accept: application/sparql-results+json` header both worked; either is fine.

### `dosearch` empty-result seam gap (characterize only — changing it is OUT OF SCOPE)

- `lib/search_ui.py:38-39` signature: `def dosearch(token, what, category, sort, limit, offset, action, params=None, update_listing=False):`
- Empty path, `lib/search_ui.py:66-69`: `if not files and offset == 0:` → `popinfo(_addon.getLocalizedString(30108), ...)` → `xbmcplugin.endOfDirectory(_handle, updateListing=update_listing)` → bare `return`.
- Gap: ALL of `dosearch`'s exits are bare `return` — :46 (API failure, after `endOfDirectory(..., succeeded=False)`), :69 (empty result), :96 (series view rendered). Returns `None` in every case; caller CANNOT distinguish "zero results" from "API failed" from "results rendered fine". `dosearch` has already called `endOfDirectory` itself, closing the Kodi directory.
- What a reroll loop would need: (a) a distinguishable zero-results signal, separate from API failure — return value or out-param, since `None` is currently ambiguous; (b) ability to NOT close the directory on empty, so the loop can pick another title and search again within the same action. Today the directory is already closed by the time the caller regains control — an external reroll cannot reuse that action's handle.
- Blast radius: one production call site, `lib/search_ui.py:407` (tests reference it at `tests/unit/test_search_history.py:383-386`, `tests/unit/test_search_guard.py:28`).
- Also relevant: `main.py:51` `_RESOLVE_ACTIONS = {'play', 'select_version', 'select_movie_version', 'newsearch', 'random_episode'}` — a new resolve-type action omitted here leaves Kodi on a hung spinner (`main.py:39-57` derives the close primitive from the action). `lib/utils.py:111-119` `ask(what)` prefills the keyboard via `xbmc.Keyboard(what, ...)` — the "search prefilled with picked title" path.

## 4. cs-title coverage, MEASURED

| sample | rows | cs present | cs % | en present | en % | P2529 present |
|---|---|---|---|---|---|---|
| OFFSET 0 (Q11) | 2000 | 1316 | 65.8% | 1997 | 99.8% | not in projection |
| OFFSET 2000 (Q9) | 500 | 289 | 57.8% | 500 | 100% | 499 |
| OFFSET 6000 (Q10) | 500 | 164 | 32.8% | 500 | 100% | 499 |
| POOLED | 3000 | 1769 | 59.0% | — | — | 998/1000 = 99.8% |

Q9/Q10 = recommended query + `OPTIONAL { ?film wdt:P2529 ?csfd }`, LIMIT 500. Q9 5.14s/189,789 B; Q10 9.72s/176,014 B; Q11 2.68s/617,843 B. Rows where cs present AND differs from en: Q9 248/289, Q10 139/164.

**Do not quote a single headline %.** cs coverage DECREASES across the three samples by offset depth (65.8% → 57.8% → 32.8%). Cause NOT established — §2.1 shows result order is not stable across calls, so this cannot be attributed to a fixed ordering that puts sparser films deeper. Treat the gradient as an observed spread, not a rule. Report the RANGE 32.8%-65.8% and the pooled 59.0%; a single number would mislead.

en label is the fallback, present in 99.8% (1997/2000). Measured edge case: 3 of 2000 rows (0.15%) had NEITHER cs nor en — pick loop must skip title-less rows.

Sample cs/en pairs: `Rudý úsvit: Nová krev`/`Red Dawn`, `Garfield ve filmu`/`Garfield: The Movie`, `Liga výjimečných`/`The League of Extraordinary Gentlemen`, `Tančírna`/`Le Bal`, `4 měsíce, 3 týdny a 2 dny`/`4 Months, 3 Weeks and 2 Days`, `Jíst, meditovat, milovat`/`Eat Pray Love`.

### P2529 ČSFD-ID bridge — verified + measured, tempered

- P2529 verified from https://www.wikidata.org/wiki/Property:P2529 as "ČSFD film ID", datatype External identifier, description "identifier for a movie in the Czech-Slovak film database ČSFD". Property talk page (https://www.wikidata.org/wiki/Property_talk:P2529) reports total uses 331,236 / main statement 326,545 — 38% completeness across eligible items.
- MEASURED on the popularity-gated pool: 998/1000 sampled rows (99.8%) carry P2529 — far above 38% global, because sitelinks>=20 selects well-documented films.
- Also verified: P345 = IMDb ID, P4947 = TMDB movie ID, P577 = publication date, P1476 = title (monolingual text). All labels matched expectation.
- **Temper:** the repo has NO lookup-by-external-id path. `csfd_scraper.py` searches by NAME only (`search_csfd(query)` at :106, detail by ČSFD film id via `get_csfd_titles(film_id)` at :161); `csfd_id` exists only as a stored column in the sqlite cache schema (:93). Round 1 also found csfd.cz actively bot-blocked. Bridge's realistic value is as a STABLE IDENTITY/DEDUP KEY carried alongside a picked title, not a live enrichment path — using it at all is a NEW capability, not wiring up something that exists.

## 5. Sufficiency verdict (against kill-criteria)

1. **cs-label coverage — NOT tripped.** 59.0% pooled (range 32.8-65.8%), en fallback 99.8%, only 0.15% unusable rows. Usable.
2. **Prefetch pool survival — NOT tripped.** `cache.py`'s in-memory API can't do it, but its on-disk primitives can; `lib/favorites.py` is a working precedent for exactly this shape at 200 items; 2,000 titles = ~68 KiB. Feasible as NEW code over EXISTING primitives.
3. **WDQS availability/latency — TRIPPED IN PART.** Honest weak point: two hard failures (504, 502) in ~30 courteous queries, latency 0.50-45.45s, one query 15s from the hard kill, WMF's own page says "much less responsive" in 2026. A live-query-per-click menu item WOULD visibly fail or feel broken with some regularity. Doesn't kill WDQS, but kills the LIVE-per-click shape and makes prefetch+cache load-bearing rather than merely nicer.

**Overall:** WDQS is sufficient FOR A PREFETCH-POOL DESIGN. NOT sufficient for a naive live-query-per-click design. Round 1's ranked fallback (TMDB, key-required) is the escalation if the prefetch design's staleness or observed failure rate proves unacceptable — do not engineer around the availability finding silently.

## 6. Cross-source portability

The seam that keeps TMDB swappable: a source returns a list of candidate records shaped `{cs_title, en_title, year?, ids{}}`; picking/reroll/exclusion, title cleanup, and the Webshare search hand-off stay source-agnostic. TMDB maps onto the same shape (`title` with `language=cs-CZ` + `original_title`, per round 1) but is key-required and paginated rather than offset-into-a-pool, so the source contract should expose "give me N candidates", NOT "give me offset X" — an offset-shaped interface would leak WDQS's pool model into the seam and force a rewrite. Popularity gating differs per source (WDQS `wikibase:sitelinks` vs TMDB `vote_count.gte`) so it belongs behind the source, not in the picker.

## 7. UNVERIFIED / not measured

- **Webshare Czech-vs-English hit rate: STILL UNMEASURED**, and why matters — corrects an intuitive-but-wrong approach. Webshare's search endpoint IS unauthenticated (verified live with `wst=` empty: HTTP status OK for every probe; repo asserts this at `tests/integration/test_api_grouping.py:6` "Webshare search API is PUBLIC - no authentication needed!" and `tests/integration/test_real_data.py:68` "No token required for search endpoint"). No credentials read or needed — integration suite ships 49 cached XML fixtures, defines `get_webshare_token()` in `test_api_grouping.py` but never calls it, stores no credential values. BUT the endpoint's `<total>` field cannot measure hit rate: a deliberate nonsense control query ("zzqqxx nonexistent gibberish title") returned `<total>1000</total>`, and "Bledě modrá tečka" returned 1000 with top filenames being Depeche Mode concert videos. Matching is fuzzy/token-based with an apparent 1000 cap — `total` does not indicate whether a given film is present. Hit-rate comparison needs per-result filename verification, not `total`. Left UNVERIFIED.
- Qualitative observation that IS supported (report as observation, not rate): Czech-market Webshare filenames frequently carry BOTH titles, e.g. measured filenames `Vykoupení z věznice Shawshank CZ (4KHDR).mkv`, `Vykoupeni z veznice Shawshank   The Shawshank Redemption 1994 CZ 2160p BRRip CZ Dabing.mkv`, `The Sixth Sense Šestý Smysl 1999 2160p HDR CZ AC3 2.0 EN DTS-HD 5.1.mkv`. Either title can plausibly hit — consistent with why the addon already does dual-name canonical merging. Not a measured hit rate.
- No deliberate rate-limit/load experiment run (out of scope by policy); throttling characterized from published docs plus incidental observation only. No 429 observed this session.
- Whether WDQS default result ORDER is guaranteed stable across calls — not tested; the offset-vs-coverage gradient implies a stable arbitrary order but this was not verified across time.
