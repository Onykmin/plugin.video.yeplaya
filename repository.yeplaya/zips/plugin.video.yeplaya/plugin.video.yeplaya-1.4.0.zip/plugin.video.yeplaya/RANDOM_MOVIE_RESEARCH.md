# Random Movie Source Research

Scope: evaluate external/in-repo sources for a "random movie" picker feature (mirrors existing random-episode picker), incl. Czech/Slovak title support, quotas, ToS, and integration hook points. No implementation plan; hook points described as-is.

## 1. Comparison Table

| Source | What it is | Key? | Randomness mechanism | Limits/quotas | License/ToS for GPL addon | CS/SK title? | Cost per pick | Verdict |
|---|---|---|---|---|---|---|---|---|
| Wikidata WDQS | SPARQL endpoint over Wikidata | no-key | random OFFSET into filtered/sorted query (measured) | 60s query timeout (docs, matches measured 60s timeout); no WDQS-specific rate limit published | CC0, public domain, no attribution needed (wikidata.org/wiki/Wikidata:Licensing) | Yes — measured cs+en pairs in one query | 1 request, ~10-15s measured latency, small JSON payload | **Best no-key** |
| MediaWiki `list=random` (cs.wikipedia) | Wikipedia random-page API | no-key | `list=random` across a namespace (mediawiki.org/wiki/API:Random) | 200 req/min (compliant UA/browser), 10/min if unidentified, 3 concurrent max (mediawiki.org/wiki/Wikimedia_APIs/Rate_limits) | Wikipedia content generally CC BY-SA (not independently re-verified here for text reuse) | Yes, cs.wikipedia titles (measured) but polluted by disambiguators, some titles stay English ("Karate Kid") | fast per docs; not directly measured for `list=random` | Usable only combined w/ categorymembers (no category-scoped random) |
| MediaWiki `list=categorymembers` (cs.wikipedia) | category enumeration API | no-key | none native — must pick random offset/index from enumerated list | same as above (200/min compliant UA) | same as above | Yes, measured live (Americké filmy: "Karate Kid", "Most (film, 2003)", etc.) | 1 request, HTTP 200 measured, but returns page-listing not RNG | Feasible but manual randomization + title cleanup needed |
| jsonfakery `/movies/random` | free hobby JSON test-data API, TMDB-derived | no-key | server-side `/random` endpoint (measured) | none documented | no documented ToS; TMDB-derived data implies TMDB's terms may ride along, unclear | No — only `original_title`/`original_language` (en) observed | 1 request, HTTP 200 measured | Works today, but off-label/fragile fallback |
| TMDB | movie metadata API | free key required | random `page` of `discover/movie` + random pick within page (no random endpoint documented) | original 40 req/10s limit disabled since 2019-12-16; unspecified upper limits remain (verified quote) | logo + attribution required; no cache >6 months; no resale/sublicense; non-commercial only w/o separate agreement (themoviedb.org/api-terms-of-use) | Yes — `language=cs-CZ`, alternative_titles filterable by CZ | 1-2 requests (discover + optional alt-titles), payload small | **Best free-key fallback** |
| OMDb | movie lookup/search API | free key required | none — no discover/random endpoint documented | 1,000/day free tier (verified live) | prohibits redistribution/copying, no business use, no derivative works w/o permission (omdbapi.com/legal.htm) | Not documented — no language param | N/A, structurally can't pick random | Reject — no randomness mechanism |
| Trakt | media metadata/tracking API | key required | no `/movies/random` endpoint found in docs or repo | UNVERIFIED (third-party only) | ToS explicitly bans "apps...that promote copyright infringement or piracy" (verified live text), forbids scraping, requires branding | UNVERIFIED (cs support not confirmed) | N/A | Reject — ToS conflict for Webshare-fronting addon |
| IMDb non-commercial datasets | bulk TSV.gz dumps | no-key (dataset) | offline random row pick after download | daily refresh; no request quota (bulk files) | "personal and non-commercial use", "cannot create any kind of online/offline database...except individual personal use", no redistribution (help.imdb.com) | Structurally yes via title.akas (CZ not enumerated in docs; 3rd-party sample shows CZ rows) | title.akas.tsv.gz measured 511,496,790 bytes (~511MB) gzipped | Reject — size + license clause blocks distributed addon |
| MovieLens ml-latest-small | CSV ratings/movies dataset | no-key (dataset) | offline random row pick after download | none (static file) | redistribution allowed under same license per README, but grouplens.org says "we typically do not permit public redistribution" (tension, both reported) | No — English titles w/ parenthesised year, not documented as localized | measured 978,202 bytes (~978KB) zip, zero network at runtime once bundled | **Best zero-network** (with caveats) |
| TVMaze | TV show/episode API | no-key | none for movies (no movie endpoints at all) | ≥20 calls/10s per IP (tvmaze.com/api) | CC BY-SA, requires attribution + ShareAlike | N/A | N/A | Reject — TV-only, no movie/random endpoint |
| Cinemagoer | Python lib wrapping IMDb non-commercial datasets | no-key (lib) | inherits IMDb dataset access, no built-in random helper documented | N/A | GPLv2 lib but inherits IMDb dataset non-commercial/no-offline-db terms | inherits IMDb dataset (see above) | requires Python ≥3.10, pip install, optional SQLAlchemy | Reject — not a Kodi script.module, pip-only, not found in xbmc/repo-scripts, kodi-community-addons |
| ČSFD | Czech film DB (csfd.cz) | no-key but bot-blocked | none — repo only has query-search + per-film detail scraping, no chart/listing endpoint (csfd_scraper.py) | site actively blocks automated access (BotStopper); ToS page unreachable to probe | UNVERIFIED (ToS unreachable); 3rd-party scraper warns "can be detected and banned" | Yes in principle (repo's own dual-name extraction), but no enumeration mechanism exists | N/A — no random capability in repo code | Reject as random source — capability gap; remains dormant alias-enricher only |

## 2. Ranked Recommendation

**Best no-key: Wikidata WDQS.**
- Only keyless option returning real structured data with a measurable, working randomization path (random OFFSET into a filtered+sorted query; measured 9.98-14.7s).
- Must use `DISTINCT` — without it, duplicate P577 statements return the same film repeated 5x (measured: all 5 rows "Blue Valentine").
- Needs a popularity filter to avoid obscure/unreleased junk — `wikibase:sitelinks >= N` is a usable keyless proxy (measured).
- Cost: ~10-15s per pick, 60s hard timeout on the public endpoint (mediawiki.org/wiki/Wikidata_Query_Service/User_Manual, matches observed timeout). `ORDER BY MD5(CONCAT(...RAND()))` does NOT scale — timed out at film-class scale (measured, no response after 60s). Must set a descriptive User-Agent per Wikimedia policy (foundation.wikimedia.org/wiki/Policy:User-Agent_policy) or risk being blocked without notice.
- CC0 license = zero attribution/compliance burden (wikidata.org/wiki/Wikidata:Licensing).

**Best free-key fallback: TMDB.**
- Technically strongest data (both `title` and `original_title`, `cs-CZ` language support, alternative_titles filterable by CZ), but requires user-obtained API key (verified: no-key request returns HTTP 401), carries mandatory logo/attribution burden, a 6-month cache ceiling, and non-commercial-use terms (all verified quotes above) — real compliance overhead for a GPL addon.
- No native random endpoint; randomness = random `page` of `discover/movie` + pick within page. `total_pages` can be large (example response showed 38,020) so page-space is ample, but max `page` value is not stated in docs.
- Rate limiting: original 40 req/10s disabled since 2019-12-16, but unspecified "upper limits" remain per the live page text — do not assume unlimited.

**Best zero-network: MovieLens ml-latest-small.**
- Only realistically-sized bundleable dataset found (measured 978KB zip) vs. IMDb's 511MB akas file or larger MovieLens variants (25M=250MB, full=335MB).
- No Czech titles documented — English only, with parenthesised release year needing stripping (movies.csv `title` col, per README).
- License tension unresolved in source docs themselves: README permits redistribution under same license; grouplens.org page says "we typically do not permit public redistribution" — report both, no verdict invented.
- No network dependency at pick-time once bundled — trades payload size for staleness (dataset is a fixed snapshot, not live).

Everything else keyless is dead (hobby endpoints), TV-only (TVMaze), or license-blocked (IMDb datasets, ČSFD bot-blocked with no enumeration mechanism in repo). jsonfakery is the only other live keyless option but is an off-label test-JSON service with no documented ToS/rate limit/pool size and no Czech title field — usable as a last-resort fallback, not a primary.

## 3. Czech/Slovak Title Verdict

| Source | CS/SK support | Evidence |
|---|---|---|
| TMDB | Yes | `language=cs-CZ` param (default `en-US`); `cs` confirmed in primary-translations config and languages config `{"iso_639_1":"cs","english_name":"Czech","name":"Český"}` (developer.themoviedb.org/reference/configuration-languages); `alternative_titles` endpoint filterable by ISO 3166-1 country incl. CZ |
| Wikidata WDQS | Yes, measured | Label service `SERVICE wikibase:label { bd:serviceParam wikibase:language "cs,en". }` returned real cs labels (e.g. "Žijeme na veřejnosti"); combined cs+en query returned pairs incl. 'Hunger Games'/'The Hunger Games', 'Kruh'/'The Ring', 'Jeden den'/'One Day' — cs and en fetched in a single request |
| cs.wikipedia (MediaWiki) | Yes, measured, noisy | Live categorymembers call returned "Karate Kid", "Most (film, 2003)", "Padesát odstínů (filmová série)" — disambiguator suffixes `(film, 2003)`, `(filmová série)` pollute the title and need stripping; some articles retain the English title unchanged ("Karate Kid") |
| IMDb datasets (title.akas) | Structurally yes, unconfirmed in docs | `region` column accepts any code; docs do not enumerate CZ; a non-authoritative third-party sample file shows one CZ row (`tt0096697 ... Simpsonovi CZ ...`) — not authoritative |
| MovieLens | No | movies.csv titles imported from TMDB per README, no language/localization documented |
| OMDb | No | no language parameter documented anywhere on omdbapi.com |
| jsonfakery | No | only `original_title` + `original_language` observed, `en` in the sampled record |

**Search-term question is UNRESOLVED by this research.** The addon already does accent-insensitive matching via `unidecode` (lib/search.py) and has dual-name canonical-key merging via `csfd_scraper.create_canonical_from_dual_names`, imported conditionally at lib/grouping.py:24-27. Webshare filenames are Czech-market releases, which suggests Czech titles could hit better — but there is no measurement in this research comparing Webshare search hit-rates for Czech vs. original/English titles. Recommendation: fetch BOTH where the source supports it (WDQS returns cs+en in one query; TMDB gives `title`+`original_title` together) and try/offer both search terms rather than asserting a winner — do not pick one without data.

## 4. Zero-Results Failure Mode

A random title has no guarantee of existing on Webshare. Concrete, source-tied mitigations:

- **Popularity gating at selection time** (reduces obscure/unreleased picks that are unlikely to be on Webshare): WDQS `wikibase:sitelinks >= N` (measured working proxy); TMDB `vote_count.gte` (documented discover param); IMDb `numVotes` (title.ratings column, "number of votes the title has received").
- **Year windows** (avoid too-new/unreleased or too-obscure-old titles): TMDB `primary_release_date.gte`/`primary_release_date.lte` (documented discover params); WDQS `P577` (release date) filter (used in the measured random-offset query).
- **Reroll-on-empty**, mirroring the existing random-episode picker precedent: lib/series_ui.py:424-435 `_pick_random(all_keys, excluded)` uses an in-memory `excluded` set scoped to one Kodi menu action/process, `random.choice(remaining)`, never auto-resets — the same shape (pick, check, exclude, repick) applies to a random-movie candidate pool.
- **Existing empty-result detection**: lib/search_ui.py:66-69 `if not files and offset == 0:` triggers `popinfo()` with string 30108 ("No results found.") then calls `endOfDirectory()` and returns. Friction to note as-is: `dosearch` currently consumes the emptiness internally and closes the Kodi directory itself — an auto-reroll loop driven from outside `dosearch` would need that empty signal to propagate back to the caller instead of `dosearch` closing the directory; this is a real seam gap, not something to design around here.
- **Try both titles** per source (cs + en/original) before declaring a miss, per §3.
- **Strip noise from titles before querying Webshare**: MovieLens parenthesised release year in `title` column; cs.wikipedia disambiguator suffixes like "(film, 2003)", "(filmová série)" (both measured/documented above).
- **SORTS do not help here**: lib/ui.py:26 `SORTS = ['','recent','rating','largest','smallest']` ranks Webshare FILES already found for a query — irrelevant to a title that returns zero Webshare files in the first place.

## 5. Integration Feasibility — Hook Points Only

(Description of existing seams; not a plan or code.)

- **Root-menu registration**: lib/ui.py:170-198 `menu()` adds items via `xbmcplugin.addDirectoryItem`. Existing precedent for a conditionally-shown root item gated by a setting: lib/ui.py:191 `if 'true' == _addon.getSetting('experimental'):`.
- **Routing action**: lib/routing.py:71-128 `router(paramstring)` — `params = dict(parse_qsl(paramstring))` (routing.py:72), long if/elif dispatch on `action`. Existing random-picker action already wired at routing.py:85-86 → `show_random_episode_dialog(params)`, same pattern would apply for a movie action.
- **main.py:51 `_RESOLVE_ACTIONS` gotcha**: any new playable/non-folder action MUST be added to `_RESOLVE_ACTIONS = {'play','select_version','select_movie_version','newsearch','random_episode'}` (main.py:51) or Kodi is left on a hung spinner by the error fallback (per commit d6723f3 message, verified at main.py:50-51).
- **Two existing search seams**:
  1. Silent: build `get_url(action='search', what=<title>, category=category, sort=sort, limit=limit, offset=0)` (pattern at lib/search_ui.py:453) then `xbmcplugin.setResolvedUrl(...)` + `xbmc.executebuiltin("Container.Update({})".format(url))` (lib/search_ui.py:455-456, as in `newsearch`).
  2. Prefilled keyboard: lib/utils.py:111-119 `ask(what)` accepts a prefill argument passed to `xbmc.Keyboard(what, ...)`, currently called as `ask(None)` at lib/search_ui.py:444 — calling it with a candidate title instead shows it pre-typed and editable, matching a "fills in the search like I would" UX.
  - Underlying search functions: `search(params)` (lib/search_ui.py:371, reads `what` from params at :387-389) → `dosearch(token, what, category, sort, limit, offset, 'search', params, update_listing=updateListing)` (:407) → `dosearch(token, what, category, sort, limit, offset, action, params=None, update_listing=False)` signature at lib/search_ui.py:38-39.
- **Reroll precedent**: an in-process `while True:` loop inside one Kodi action using an in-memory `excluded` set (lib/series_ui.py:424-435 `_pick_random`), documented rationale: "one Kodi menu action = one process," so backing out and re-entering deliberately starts fresh. Dialog rows in the episode picker: Play / Pick version / Reroll / Cancel, with a "Start over" option once the pool is exhausted (lib/series_ui.py:474 `show_random_episode_dialog`, :438 `_build_dialog_rows`).
- **Opt-in setting pattern**: bool setting + `lsep` label precedent — resources/settings.xml:36 (`lsep` label 30433) and :37 (`<setting label="30439" id="random_episode" type="bool" default="false" />`, opt-in/default off). 3-locale strings.po convention: strings 30433-30443 added to en_gb, cs_cz, sk_sk in the random-episode feature (commit d6723f3).
- **Pool persistence options**, ranked by precedent strength (relevant because Kodi is one-process-per-action so any cross-action pool needs a durable store):
  1. lib/state.py — sqlite3-backed cross-process store (`import sqlite3` :14, `_get_db_path` :39, `_connect(... check_same_thread=False, timeout=5.0)` :53, `_migrate` :59, `get_state`/`get_states` :258/:282).
  2. csfd_scraper.py:59 `init_csfd_cache()` — its own sqlite db in the addon profile dir.
  3. lib/cache.py — `profile_dir()` (:170), `atomic_write_text(path, text)` (:275, "unique tmp file + os.replace"), `locked_read_text(path)` (:260); search-history persistence via `loadsearch()`/`savesearch()`/`storesearch()` (:303/:329/:334).
  4. Hidden text-setting precedent: resources/settings.xml:39 `<setting id="changelog_seen_version" type="text" visible="false" default="" />`.
  5. NOT viable alone: lib/cache.py in-memory `cache_set`/`cache_get` (:64/:86) with `DEFAULT_CACHE_TTL = 300` (:55) — per-process, dies every menu action (project gotcha: "each menu action = fresh Python process → in-memory cache resets").
- **Dependency ceiling**: addon.xml:3-7 `<requires>` lists only `script.module.requests` 2.18.4+ and `script.module.unidecode` 0.4.16+ on top of `xbmc.python` 3.0.0 (Kodi's python-addon ABI version, not a Python language version). No pandas/SPARQLWrapper/BeautifulSoup/lxml available. Any WDQS/TMDB/MediaWiki call must go through `requests` + manual JSON parsing; `json`, `gzip`, `csv`, `sqlite3`, `random` are Python stdlib and already used in-repo (e.g. `random` in lib/series_ui.py:8, `sqlite3` in lib/state.py:14).

## 6. UNVERIFIED / Rejected

**UNVERIFIED** (explicitly not confirmed by any fetched source — do not treat as fact):
- W3C SPARQL 1.1 spec text for `RAND()`/`ORDER BY` semantics (page could not be retrieved verbatim, truncated).
- WDQS-specific published rate/throttling numbers (only REST API and Action API numbers are published at wikitech.wikimedia.org/wiki/Robot_policy; those govern other Wikimedia services, not SPARQL/WDQS).
- TMDB's current post-2019 "upper limits" on request rate (page text truncated after mentioning they still exist).
- Whether TMDB's `title` field in movie-details is localized by the `language` param (not stated in docs).
- Whether TMDB permits bundling an API key inside a distributed addon (not stated in ToS).
- OMDb `page` param "1-100 range" (only "Page number to return" is documented; the 1-100 claim came from an unverified probe).
- Trakt rate limits ("1,000 calls per 5 minutes"), default/max pagination, response field shapes, `movies/:id/translations/:language` endpoint, and `cs` language support — all from third-party sources only (apis.guru, GitHub discussions, pytrakt/rdrr.io wrapper docs), not official Trakt docs.
- IMDb `title.akas` CZ region enumeration — docs don't list supported region codes; only a third-party sample file shows one CZ row.
- csfd.cz Terms of Service text — site/terms page unreachable to the probe (BotStopper).
- jsonfakery pool size, ToS, and rate limits — none documented anywhere found.
- MovieLens redistribution permission — README and main dataset page directly conflict (README allows redistribution under same license; grouplens.org says public redistribution is "typically" not permitted).
- Webshare Czech-vs-English title hit-rate — no measurement exists in this research; the Czech-vs-English question in §3 is open, not resolved.

**REJECTED**, with reason:
- TVMaze — TV-only, no movie endpoints, no random endpoint.
- Cinemagoer — pip-only Python lib, no Kodi `script.module` packaging found in xbmc/repo-scripts or kodi-community-addons; inherits IMDb dataset licensing.
- IMDb non-commercial datasets — 511MB akas file for CZ titles alone, plus explicit "cannot create any kind of online/offline database...except individual personal use" clause conflicts with a distributed GPL addon.
- OMDb — no discover/listing/random mechanism exists in the documented API at all.
- Trakt — ToS explicitly prohibits "apps or websites that promote copyright infringement or piracy" (verified live text), a substantive risk for a Webshare-fronting addon; also requires a key and forbids scraping.
- ČSFD — csfd.cz blocks automated access (BotStopper), no documented public API, no listing/chart/random endpoint anywhere in repo's own csfd_scraper.py (only query-search + per-film detail scraping exist).
- Dead hobby endpoints (all confirmed by direct fetch): randommovienameapi.herokuapp.com (HTTP 404, confirmed twice), multimoviesapis.vercel.app (HTTP 402), moviesapi.proyato.com (DNS ENOTFOUND), mockx.net (DNS ENOTFOUND), freetestapi.com/apis/movies (blank), filmapi.vercel.app / cool-movie-api.vercel.app (landing page only, no docs), api.sampleapis.com (no movies/random endpoint), mockapi.dog (mock builder, not a movie database).

## Bottom Line

No single source is both robust and Czech-native without a key. WDQS is the only strong keyless real-data option but costs ~10-15s/pick with hard 60s timeouts and needs `DISTINCT` + a `wikibase:sitelinks` popularity filter to avoid dupes/junk. TMDB is the technically best overall (cs-CZ + original_title + alt-titles) but requires a user-supplied key and carries logo/attribution + 6-month cache + non-commercial-use obligations. MovieLens ml-latest-small (~978KB, measured) is the only realistic zero-network bundle, at the cost of English-only titles and an unresolved redistribution-permission tension in its own docs. The Czech-vs-English Webshare hit-rate question is unmeasured and should not be pre-decided — fetch both title variants where the source allows it.
